from django.contrib import admin
from . models import Jadwal_imsyak

# Register your models here.
admin.site.register(Jadwal_imsyak)
